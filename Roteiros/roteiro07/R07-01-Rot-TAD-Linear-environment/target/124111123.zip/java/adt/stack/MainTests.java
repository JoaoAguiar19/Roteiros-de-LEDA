package adt.stack;

public class MainTests {
    public static final String RESET = "\u001B[0m";
    public static final String VERMELHO = "\u001B[31m";
    public static final String VERDE = "\u001B[32m";

    public static void main(String[] args) throws StackOverflowException, StackUnderflowException{
        StackImpl<Integer> stack = new StackImpl<>(3);

        // Pilha vazia
        System.out.println("stack vazia: " + VERMELHO + stack.top() + RESET); // Deve retornar null
        System.out.println("A stack está vazia: " + VERDE + stack.isEmpty() + RESET); // true
        System.out.println("A stack está cheia: " + VERMELHO + stack.isFull() + RESET); // false

        // Adicionando elementos na stack
        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println("--------------------------------------------------");
        
        // stack cheia
        System.out.println("stack cheia: " + stack.top()); // Deve retornar 1
        System.out.println("A stack está vazia: " + VERMELHO + stack.isEmpty() + RESET); // false
        System.out.println("A stack está cheia: " + VERDE + stack.isFull() + RESET); // true
        
        System.out.println("--------------------------------------------------");

        // Remover elemento
        System.out.println("Valor removido: " + stack.pop()); // retorn 1
        System.out.println("Proximo a ser removido: " + stack.top()); // return 2
        System.out.println("A stack está vazia: " + VERMELHO + stack.isEmpty() + RESET); // false
        System.out.println("A stack está cheia: " + VERMELHO + stack.isFull() + RESET); // false
        
        
        
        System.out.println("--------------------------------------------------");
        
        // UnderFlow
        try {
            System.out.println("Valor removido: " + stack.pop()); // retorn 2
            System.out.println("Valor removido: " + stack.pop()); // retorn 3
            System.out.println("Valor removido: " + stack.pop()); // falha
            
        } catch (StackUnderflowException e) {
            System.out.println(VERMELHO + "Caiu na exceção. Você tentou remover em uma stack vazia" + RESET);
        }
        
        System.out.println("--------------------------------------------------");
        
        // OverFlow
        try {
            stack.push(7);
            stack.push(2);
            stack.push(5);
            stack.push(9);

        } catch (StackOverflowException e) {
            System.out.println(VERMELHO + "Caiu na exceção. Você tentou adicionar em uma stack cheia" + RESET);   
        }

    }
}
